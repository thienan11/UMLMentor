import org.hamcrest.CoreMatchers;
import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;
import static org.junit.Assert.assertEquals;
public class LexerTests {

    @Test
    public void TestIsEmpty(){
        String text = "";
        try {
            List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\arrie\\IdeaProjects\\309_Code\\Parser\\emptyTest.txt"));
            text = "";
            for (String line : lines) {
                text = text + line + "\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Lexer l = new Lexer(text);
        l.run();
        Vector<Token> CorrectTokens = new Vector<>();
        assertEquals(CorrectTokens, l.getTokens());
    }

    @Test
    public void EmptyOneClass(){
        String text = "";
        try {
            List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\arrie\\IdeaProjects\\309_Code\\Parser\\oneClass.txt"));
            text = "";
            for (String line : lines) {
                text = text + line + "\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Lexer l = new Lexer(text);
        l.run();
        Vector<Token> CorrectTokens = new Vector<>();
        CorrectTokens.add(new Token("class", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("One", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("{", "DELIMITER", 1));
        CorrectTokens.add(new Token("}", "DELIMITER", 1));
        assertEquals(CorrectTokens, l.getTokens());
    }

    @Test
    public void EmptyOneClassSpacing(){
        String text = "";
        try {
            List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\arrie\\IdeaProjects\\309_Code\\Parser\\oneClassSpacing.txt"));
            text = "";
            for (String line : lines) {
                text = text + line + "\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Lexer l = new Lexer(text);
        l.run();
        Vector<Token> CorrectTokens = new Vector<>();
        CorrectTokens.add(new Token("class", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("one", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("{", "DELIMITER", 1));
        CorrectTokens.add(new Token("}", "DELIMITER", 6));
        assertEquals(CorrectTokens, l.getTokens());
    }

    @Test
    public void OneClassWithMethodAndVars(){
        String text = "";
        try {
            List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\arrie\\IdeaProjects\\309_Code\\Parser\\test.txt"));
            text = "";
            for (String line : lines) {
                text = text + line + "\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Lexer l = new Lexer(text);
        l.run();
        Vector<Token> CorrectTokens = new Vector<>();
        CorrectTokens.add(new Token("class", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("Test", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("extends", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("R", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("{", "DELIMITER", 1));
        CorrectTokens.add(new Token("Z", "IDENTIFIER", 2));
        CorrectTokens.add(new Token("z", "IDENTIFIER", 2));
        CorrectTokens.add(new Token(";", "DELIMITER", 2));
        CorrectTokens.add(new Token("Y", "IDENTIFIER", 3));
        CorrectTokens.add(new Token("y", "IDENTIFIER", 3));
        CorrectTokens.add(new Token(";", "DELIMITER", 3));
        CorrectTokens.add(new Token("X", "IDENTIFIER", 4));
        CorrectTokens.add(new Token("x", "IDENTIFIER", 4));
        CorrectTokens.add(new Token(";", "DELIMITER", 4));
        CorrectTokens.add(new Token("W", "IDENTIFIER", 5));
        CorrectTokens.add(new Token("w", "IDENTIFIER", 5));
        CorrectTokens.add(new Token(";", "DELIMITER", 5));
        CorrectTokens.add(new Token("V", "IDENTIFIER", 6));
        CorrectTokens.add(new Token("v", "IDENTIFIER", 6));
        CorrectTokens.add(new Token(";", "DELIMITER", 6));
        CorrectTokens.add(new Token("int", "KEYWORD", 7));
        CorrectTokens.add(new Token("method", "IDENTIFIER", 7));
        CorrectTokens.add(new Token("(", "DELIMITER", 7));
        CorrectTokens.add(new Token(")", "DELIMITER", 7));
        CorrectTokens.add(new Token("{", "DELIMITER", 7));
        CorrectTokens.add(new Token("U", "IDENTIFIER", 8));
        CorrectTokens.add(new Token("u", "IDENTIFIER", 8));
        CorrectTokens.add(new Token(";", "DELIMITER", 8));
        CorrectTokens.add(new Token("}", "DELIMITER", 9));
        CorrectTokens.add(new Token("}", "DELIMITER", 10));
        assertEquals(CorrectTokens, l.getTokens());
    }

    @Test
    public void multipleMethods(){
        String text = "";
        try {
            List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\arrie\\IdeaProjects\\309_Code\\Parser\\multipleMethods.txt"));
            text = "";
            for (String line : lines) {
                text = text + line + "\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Lexer l = new Lexer(text);
        l.run();
        Vector<Token> CorrectTokens = new Vector<Token>(Arrays.asList(new Token("class", "IDENTIFIER", 1),
                new Token("A", "IDENTIFIER", 1),
                new Token("{", "DELIMITER", 1),
                new Token("void", "KEYWORD", 2),
                new Token("methodA", "IDENTIFIER", 2),
                new Token("(", "DELIMITER", 2),
                new Token(")", "DELIMITER", 2),
                new Token("{", "DELIMITER", 2),
                new Token("B", "IDENTIFIER", 3),
                new Token("b", "IDENTIFIER", 3),
                new Token(";", "DELIMITER", 3),
                new Token("}", "DELIMITER", 4),
                new Token("C", "IDENTIFIER", 5),
                new Token("variableA", "IDENTIFIER", 5),
                new Token(";", "DELIMITER", 5),
                new Token("void", "KEYWORD", 6),
                new Token("methodB", "IDENTIFIER", 6),
                new Token("(", "DELIMITER", 6),
                new Token(")", "DELIMITER", 6),
                new Token("{", "DELIMITER", 6),
                new Token("variableA", "IDENTIFIER", 7),
                new Token("=", "OPERATOR", 7),
                new Token("new", "IDENTIFIER",7),
                new Token("C", "IDENTIFIER", 7),
                new Token("(", "DELIMITER", 7),
                new Token(")", "DELIMITER", 7),
                new Token(";", "DELIMITER", 7)));
        assertEquals(CorrectTokens, l.getTokens());
    }

    @Test
    public void typeTest(){
        String text = "";
        try {
            List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\arrie\\IdeaProjects\\309_Code\\Parser\\typeTest.txt"));
            text = "";
            for (String line : lines) {
                text = text + line + "\n";
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Lexer l = new Lexer(text);
        l.run();
        Vector<Token> CorrectTokens = new Vector<>();
        CorrectTokens.add(new Token("class", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("A", "IDENTIFIER", 1));
        CorrectTokens.add(new Token("{", "DELIMITER", 1));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 2));
        CorrectTokens.add(new Token("=", "OPERATOR", 2));
        CorrectTokens.add(new Token("1", "INTEGER", 2));
        CorrectTokens.add(new Token(";", "DELIMITER", 2));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 3));
        CorrectTokens.add(new Token("=", "OPERATOR", 3));
        CorrectTokens.add(new Token("0x1", "HEXADECIMAL", 3));
        CorrectTokens.add(new Token(";", "DELIMITER", 3));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 4));
        CorrectTokens.add(new Token("=", "OPERATOR", 4));
        CorrectTokens.add(new Token("07", "OCTAL", 4));
        CorrectTokens.add(new Token(";", "DELIMITER", 4));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 5));
        CorrectTokens.add(new Token("=", "OPERATOR", 5));
        CorrectTokens.add(new Token("0b1", "BINARY", 5));
        CorrectTokens.add(new Token(";", "DELIMITER", 5));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 6));
        CorrectTokens.add(new Token("=", "OPERATOR", 6));
        CorrectTokens.add(new Token("1.1", "FLOAT", 6));
        CorrectTokens.add(new Token(";", "DELIMITER", 6));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 7));
        CorrectTokens.add(new Token("=", "OPERATOR", 7));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 7));
        CorrectTokens.add(new Token("+", "OPERATOR", 7));
        CorrectTokens.add(new Token("1", "INTEGER", 7));
        CorrectTokens.add(new Token(";", "DELIMITER", 7));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 8));
        CorrectTokens.add(new Token("=", "OPERATOR", 8));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 8));
        CorrectTokens.add(new Token("-", "OPERATOR", 8));
        CorrectTokens.add(new Token("1", "INTEGER", 8));
        CorrectTokens.add(new Token(";", "DELIMITER", 8));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 9));
        CorrectTokens.add(new Token("=", "OPERATOR", 9));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 9));
        CorrectTokens.add(new Token("/", "OPERATOR", 9));
        CorrectTokens.add(new Token("1", "INTEGER", 9));
        CorrectTokens.add(new Token(";", "DELIMITER", 9));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 10));
        CorrectTokens.add(new Token("=", "OPERATOR", 10));
        CorrectTokens.add(new Token("i", "IDENTIFIER", 10));
        CorrectTokens.add(new Token("*", "OPERATOR", 10));
        CorrectTokens.add(new Token("1", "INTEGER", 10));
        CorrectTokens.add(new Token(";", "DELIMITER", 10));
        CorrectTokens.add(new Token("/", "OPERATOR", 11));
        CorrectTokens.add(new Token("/", "OPERATOR", 11));
        CorrectTokens.add(new Token("'\"", "ERROR", 11));
        CorrectTokens.add(new Token("@Test", "ERROR", 12));
        CorrectTokens.add(new Token("public", "IDENTIFIER", 13));
        CorrectTokens.add(new Token("void", "KEYWORD", 13));
        CorrectTokens.add(new Token("x", "IDENTIFIER", 13));
        CorrectTokens.add(new Token("(", "DELIMITER", 13));
        CorrectTokens.add(new Token(")", "DELIMITER", 13));
        CorrectTokens.add(new Token("{", "DELIMITER", 13));
        CorrectTokens.add(new Token("String", "IDENTIFIER", 14));
        CorrectTokens.add(new Token("s", "IDENTIFIER", 14));
        CorrectTokens.add(new Token("=", "OPERATOR",14));
        CorrectTokens.add(new Token("\"\\t\"", "STRING", 14));
        CorrectTokens.add(new Token(";", "DELIMITER", 14));
        CorrectTokens.add(new Token("String", "IDENTIFIER", 15));
        CorrectTokens.add(new Token("g", "IDENTIFIER", 15));
        CorrectTokens.add(new Token("=", "OPERATOR", 15));
        CorrectTokens.add(new Token("\"\\\"hi\\\"\"", "STRING", 15));
        CorrectTokens.add(new Token(";", "DELIMITER", 15));
        CorrectTokens.add(new Token("char", "KEYWORD", 16));
        CorrectTokens.add(new Token("c", "IDENTIFIER", 16));
        CorrectTokens.add(new Token("=", "OPERATOR", 16));
        CorrectTokens.add(new Token("\'a\'", "CHARACTER", 16));
        CorrectTokens.add(new Token(";", "DELIMITER", 16));
        CorrectTokens.add(new Token("\\", "ERROR", 18));
        CorrectTokens.add(new Token("\'", "ERROR", 18));
        CorrectTokens.add(new Token("}", "DELIMITER", 19));
        CorrectTokens.add(new Token("$", "IDENTIFIER", 20));
        CorrectTokens.add(new Token("\"", "ERROR", 21));
        CorrectTokens.add(new Token("\'", "ERROR", 22));
        CorrectTokens.add(new Token("@", "ERROR", 23));
        CorrectTokens.add(new Token("}", "DELIMITER", 24));

        assertEquals(CorrectTokens, l.getTokens());
    }
}
