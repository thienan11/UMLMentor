/**
 * CSC 309 UML Tutor
 * Handles program initialization
 * 
 * @author Chloe Anbarcioglu
 * @author Alex Arrieta
 * @author Thien An Tran
 * @author Mario Vuletic
 * @version 2.0
 */
public class Main{
    public static void main(String[] args){
        new UserInterface();
    }
}
